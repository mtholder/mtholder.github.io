This directory has some scripts for hypothesis testing 
  for the data on pairs of fights discussed at the end of the lecture
  slides.

These simple approaches to optimization break down on this problem
  because the shape of the likelihood surface is difficult.

There is a lot of discussion of how to solve this sort of problem by 
  reparameterizing in the sufficientAndIdentExample.pdf included
  in the posted-day-2 archive.